 import express from 'express';
 //Creamos la aplicación a través del paquete express
 // y llamamos a su contructor
const app = express();
//Todo lo que regresa al usuario es tipo JSON
app.use(express.json());
//Puerto para escuchar la petición del frontend
const PUERTO = 3001;

app.get('/hola', (_req,res) => {
    let fecha = new Date().toLocaleDateString();
    res.send('mundo con la fecha '+fecha+" con TypeScirpt");
});

//Encendemos el servidor y lo ponemos en escucha
app.listen(PUERTO,() => {
    console.log(`Servidor en ejecuión y escuchando en el puerto ${PUERTO}`);
})



