const multiplicar = (a:number,b:number,imprimir:string) => {
    console.log(imprimir,a*b);
}
multiplicar(2,4,"El resultado es:");
// multiplicar(2,true,"El resultado es:");