let mensaje = "Hola JavaScript";
console.log(mensaje);
console.log(typeof(mensaje));

mensaje = 2;
console.log(mensaje);
console.log(typeof(mensaje)); 