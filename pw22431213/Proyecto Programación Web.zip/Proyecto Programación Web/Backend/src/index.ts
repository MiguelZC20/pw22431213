 import express from 'express';
 //Creamos la aplicación a través del paquete express
 // y llamamos a su contructor
const app = express();
//Configurar rutas para el acceso a personas
import cors from 'cors';
import personalRutas from './routes/personalRutas';
import clientesRutas from './routes/clientesRutas';
import registroRutas from './routes/registroRutas';
import articulosRutas from './routes/articulosRutas';
import ventasRutas from './routes/ventasRutas';
import comprasRutas from './routes/comprasRutas';

//Todo lo que regresa al usuario es tipo JSON
app.use(express.json());
app.use(cors());
//Puerto para escuchar la petición del frontend
const PUERTO = 3001;
//Activar la ruta base
app.use('/api/personal', personalRutas);
app.use('/api/clientes', clientesRutas);
app.use('/api/registro', registroRutas);
app.use('/api/articulos', articulosRutas);
app.use('/api/ventas', ventasRutas);
app.use('/api/compras', comprasRutas);


// app.get('/hola', (_req,res) => {
//     let fecha = new Date().toLocaleDateString();
//     res.send('mundo con la fecha '+fecha+" con TypeScirpt");
// });

//Encendemos el servidor y lo ponemos en escucha
app.listen(PUERTO,() => {
    console.log(`Servidor en ejecuión y escuchando en el puerto ${PUERTO}`);
})



