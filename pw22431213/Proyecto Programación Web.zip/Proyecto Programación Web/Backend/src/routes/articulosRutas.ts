import express, { Request, Response } from 'express';
import * as articulosServices from '../services/articulosServices';

const router = express.Router();

//http://localhost:3001/api/articulos
// GET - Obtener todos los artículos
router.get('/', async (_req: Request, res: Response) => {
    const articulos = await articulosServices.obtenerArticulos();
    res.send(articulos);
});

//http://localhost:3001/api/articulos/1 
router.get('/:id', async(req: Request,res:Response)=>{
    let personal = await articulosServices.encuentraArticulo(Number(req.params.id));
    res.send(personal);
})

// POST - Agregar un artículo
router.post('/', async (req: Request, res: Response) => {
    try {
        const { descripcion, precio, cantidad_en_almacen, fecha_caducidad } = req.body;
        const nuevoArticulo = await articulosServices.agregarArticulo({
            descripcion,
            precio,
            cantidad_en_almacen,
            fecha_caducidad,
        });
        res.send(nuevoArticulo);
    } catch (e) {
        res.status(400).send("No se puede agregar el artículo");
    }
});

// PUT - Modificar un artículo
router.put('/', async (req: Request, res: Response) => {
    try {
        const { id, descripcion, precio, cantidad_en_almacen, fecha_caducidad } = req.body;
        const modificado = await articulosServices.modificarArticulo({
            id,
            descripcion,
            precio,
            cantidad_en_almacen,
            fecha_caducidad,
        });
        res.send(modificado);
    } catch (e) {
        res.status(400).send("No se puede modificar el artículo");
    }
});

// DELETE - Borrar un artículo
router.delete('/', async (req: Request, res: Response) => {
    try {
        const { id } = req.body;
        const eliminado = await articulosServices.borrarArticulo(Number(id));
        res.send(eliminado);
    } catch (e) {
        res.status(400).send("No se puede borrar el artículo");
    }
});

export default router;
