// src/routes/comprasRutas.ts

import express, { Request, Response } from 'express';
import * as comprasServices from '../services/comprasServices';

const router = express.Router();

//http://localhost:3001/api/compras
// Obtener todas las compras
router.get('/', async (_req: Request, res: Response) => {
    const compras = await comprasServices.obtenerCompras();
    res.send(compras);
});

//http://localhost:3001/api/ventas/1 
router.get('/:id', async(req: Request,res:Response)=>{
    let compras = await comprasServices.encuentraCompra(Number(req.params.id));
    res.send(compras);
})

// Registrar una nueva compra
router.post('/', async (req: Request, res: Response) => {
    try {
        const { id_articulo, cantidad, precio, iva, subtotal, total, fecha_compra } = req.body;
        const nuevaCompra = await comprasServices.agregarCompra({
            id_articulo,
            cantidad,
            precio,
            iva,
            subtotal,
            total,
            fecha_compra
        });
        res.send(nuevaCompra);
    } catch (e) {
        res.status(400).send("No se puede agregar la compra");
    }
});

// Modificar una compra existente
router.put('/', async (req: Request, res: Response) => {
    try {
        const { id, id_articulo, cantidad, precio, iva, subtotal, total, fecha_compra } = req.body;
        const compraModificada = await comprasServices.modificarCompra({
            id,
            id_articulo,
            cantidad,
            precio,
            iva,
            subtotal,
            total,
            fecha_compra
        });
        res.send(compraModificada);
    } catch (e) {
        res.status(400).send("No se puede modificar la compra");
    }
});

// Eliminar una compra
router.delete('/', async (req: Request, res: Response) => {
    try {
        const { id } = req.body;
        const compraEliminada = await comprasServices.borrarCompra(Number(id));
        res.send(compraEliminada);
    } catch (e) {
        res.status(400).send("No se puede eliminar la compra");
    }
});

export default router;
