import express, { Request, Response } from 'express';
import * as registroServices from '../services/registroServices';

const router = express.Router();

//http://localhost:3001/api/registro
// GET - Obtener todos los registros
router.get('/', async (_req: Request, res: Response) => {
    const registros = await registroServices.obtenerRegistros();
    res.send(registros);
});

//http://localhost:3001/api/personal/1 <--- número de id del personal
router.get('/:id', async(req: Request,res:Response)=>{
    let registro = await registroServices.encuentraRegistro(Number(req.params.id));
    res.send(registro);
})

// POST - Agregar un registro
router.post('/', async (req: Request, res: Response) => {
    try {
        const { id_personal, fecha, hora, movimiento } = req.body;
        const nuevoRegistro = await registroServices.agregarRegistro({
            id_personal,
            fecha,
            hora,
            movimiento
        });
        res.send(nuevoRegistro);
    } catch (e) {
        res.status(400).send("No se puede agregar el registro");
    }
});

// DELETE - Borrar un registro
router.delete('/', async (req: Request, res: Response) => {
    try {
        const { id } = req.body;
        const eliminado = await registroServices.borrarRegistro(Number(id));
        res.send(eliminado);
    } catch (e) {
        res.status(400).send("No se puede borrar el registro");
    }
});

export default router;
