import express, { Request, Response } from 'express';
import * as ventasServices from '../services/ventasServices';

const router = express.Router();

//http://localhost:3001/api/ventas
// Obtener todas las ventas
router.get('/', async (_req: Request, res: Response) => {
    const ventas = await ventasServices.obtenerVentas();
    res.send(ventas);
});

//http://localhost:3001/api/ventas/1 
router.get('/:id', async(req: Request,res:Response)=>{
    let ventas = await ventasServices.encuentraVenta(Number(req.params.id));
    res.send(ventas);
})

// Registrar una nueva venta
router.post('/', async (req: Request, res: Response) => {
    try {
        const { id_articulo, id_cliente, cantidad, precio, iva, subtotal, total, fecha_venta } = req.body;
        const nuevaVenta = await ventasServices.agregarVenta({
            id_articulo,
            id_cliente,
            cantidad,
            precio,
            iva,
            subtotal,
            total,
            fecha_venta
        });
        res.send(nuevaVenta);
    } catch (e) {
        res.status(400).send("No se puede agregar la venta");
    }
});

// Modificar una venta existente
router.put('/', async (req: Request, res: Response) => {
    try {
        const { id, id_articulo, id_cliente, cantidad, precio, iva, subtotal, total, fecha_venta } = req.body;
        const ventaModificada = await ventasServices.modificarVenta({
            id,
            id_articulo,
            id_cliente,
            cantidad,
            precio,
            iva,
            subtotal,
            total,
            fecha_venta
        });
        res.send(ventaModificada);
    } catch (e) {
        res.status(400).send("No se puede modificar la venta");
    }
});

// Eliminar una venta
router.delete('/', async (req: Request, res: Response) => {
    try {
        const { id } = req.body;
        const ventaEliminada = await ventasServices.borrarVenta(Number(id));
        res.send(ventaEliminada);
    } catch (e) {
        res.status(400).send("No se puede eliminar la venta");
    }
});

export default router;
