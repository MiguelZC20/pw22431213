import { z } from 'zod';

export const articuloSchema = z.object({
    descripcion: z.string().min(1, "La descripción es obligatoria"),
    precio: z.number().positive("El precio debe ser mayor a 0"),
    cantidad_en_almacen: z.number().int().nonnegative("La cantidad debe ser un número no negativo"),
    fecha_caducidad: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Fecha inválida (formato YYYY-MM-DD)").optional(),
})
.or(
    z.object({
        id: z.number().int().positive().min(1).max(9999)
    })
)
