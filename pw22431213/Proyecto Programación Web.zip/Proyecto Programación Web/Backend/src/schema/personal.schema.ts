import { z } from 'zod'
const telefonoRegEx = new RegExp(
    /^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$/
);
const nombreRegEx = new RegExp(
    /^[A-Za-z]+$/
);
const domicilioRegEx = new RegExp(
    /^[A-Za-z0-9/#]+$/
);

//Validaciones con Zod - construir esquema
export const personaSchema = z.object({
    // nombre: z.string().min(2,"Mínimo 2 caracteres").max(200,"Máximo 200 caracteres"),
    nombre: z.string().regex(nombreRegEx),
    // direccion: z.string().min(2).max(300),
    direccion: z.string().regex(domicilioRegEx),
    // telefono: z.string().min(10).max(15),
    telefono: z.string().regex(telefonoRegEx),
    estatus: z.number().int().positive()
    // estatus: z.number().int().positive().min(1).max(2,"Los valores correctos son 1 y 2")
}).refine(data => data.estatus <=2,{
    message: "Los valores correctos son 1(vigente) y 2(baja)",
    path:["estatus"]
}).or(
    z.object({
        telefono: z.string().min(10).max(15)
    })
)
.or(
    z.object({
        nombre: z.string().min(2,"Mínimo 2 caracteres").max(200,"Máximo 200 caracteres")
    })
)
.or(
    z.object({
        id: z.number().int().positive().min(1).max(9999)
    })
)