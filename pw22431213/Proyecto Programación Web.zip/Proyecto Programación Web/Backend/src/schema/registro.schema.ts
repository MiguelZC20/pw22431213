import { z } from 'zod';

export const registroSchema = z.object({
    id_personal: z.number().positive(),
    fecha: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Fecha inválida (formato YYYY-MM-DD)"),
    hora: z.string().regex(/^\d{2}:\d{2}:\d{2}$/, "Hora inválida (formato HH:MM:SS)"),
    movimiento: z.enum(["entrada", "salida"]),
})
.or(
    z.object({
        id: z.number().int().positive().min(1).max(9999)
    })
)