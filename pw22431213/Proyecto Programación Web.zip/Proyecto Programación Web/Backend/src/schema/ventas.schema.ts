import { z } from 'zod';

export const ventaSchema = z.object({
    id_articulo: z.number().int().positive(),
    id_cliente: z.number().int().positive(),
    cantidad: z.number().int().nonnegative(),
    precio: z.number().positive(),
    iva: z.number().positive(),
    subtotal: z.number().positive(),
    total: z.number().positive(),
    fecha_venta: z.string().regex(/^\d{4}-\d{2}-\d{2}$/)
})
.or(
    z.object({
        id: z.number().int().positive().min(1).max(9999)
    })
)
