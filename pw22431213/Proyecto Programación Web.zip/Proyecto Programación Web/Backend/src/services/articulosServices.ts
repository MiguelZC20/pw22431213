import { conexion } from './personalServices';
import { Articulo, ArticuloNuevo } from '../typesArticulos';
import { articuloSchema } from '../schema/articulos.schema';

export const obtenerArticulos = async () => {
    try {
        const [results] = await conexion.query('SELECT * FROM articulos');
        return results;
    } catch (err) {
        return { error: "No se pueden obtener los artículos" };
    }
};

export const encuentraArticulo= async (id:number) =>{
    try{
        const identificador = {id: id}
        const validacion = articuloSchema.safeParse(identificador);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('SELECT * FROM articulos WHERE id = ? LIMIT 1',id);
        return results;
    }catch(err){
        return {error: "No se encuentra ese articulo"};
    }
}

export const agregarArticulo = async (nuevo: ArticuloNuevo) => {
    try {
        const validacion = articuloSchema.safeParse(nuevo);
        if (!validacion.success) {
            return { error: validacion.error };
        }
        const [results] = await conexion.query('INSERT INTO articulos (descripcion, precio, cantidad_en_almacen, fecha_caducidad) VALUES (?, ?, ?, ?)', [
            nuevo.descripcion,
            nuevo.precio,
            nuevo.cantidad_en_almacen,
            nuevo.fecha_caducidad,
        ]);
        return results;
    } catch (err) {
        return { error: "No se puede agregar el artículo" };
    }
};

export const modificarArticulo = async (modificado: Articulo) => {
    try {
        const [results] = await conexion.query('UPDATE articulos SET descripcion=?, precio=?, cantidad_en_almacen=?, fecha_caducidad=? WHERE id=?', [
            modificado.descripcion,
            modificado.precio,
            modificado.cantidad_en_almacen,
            modificado.fecha_caducidad,
            modificado.id,
        ]);
        return results;
    } catch (err) {
        return { error: "No se puede modificar el artículo" };
    }
};

export const borrarArticulo = async (id: number) => {
    try {
        const [results] = await conexion.query('DELETE FROM articulos WHERE id = ?', [id]);
        return results;
    } catch (err) {
        return { error: "No se puede borrar el artículo" };
    }
};
