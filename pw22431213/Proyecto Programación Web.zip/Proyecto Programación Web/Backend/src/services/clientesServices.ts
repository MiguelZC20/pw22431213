import { Cliente, ClienteNuevo } from '../typesCliente';
// import mysql from 'mysql2/promise';
import { clienteSchema } from '../schema/clientes.schema';
import { conexion } from '../services/personalServices';

// export const conexion = mysql.createPool({
//     host: 'localhost',
//     user: "admin",
//     password: "pw123456",
//     database: "pw2024",
//     port: 3306,
//     multipleStatements: false
// });

export const obtieneCliente = async () =>{
    try{
        const [results] = await conexion.query('SELECT * FROM CLIENTES');
        return results;
    }catch(err){
        return {error: "No se puede obtener los clientes"};
    }
}
export const encuentraCliente= async (id:number) =>{
    try{
        const identificador = {id: id}
        const validacion = clienteSchema.safeParse(identificador);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('SELECT * FROM clientes WHERE id = ? LIMIT 1',id);
        return results;
    }catch(err){
        return {error: "No se encuentra ese cliente"};
    }
}

export const agregarCliente = async (nuevo:ClienteNuevo) =>{
    try{
        const validacion = clienteSchema.safeParse(nuevo);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('INSERT INTO clientes(nombre,direccion,telefono,correo_electronico,ciudad) values(?,?,?,?,?)',[nuevo.nombre,nuevo.direccion,nuevo.telefono,nuevo.correo_electronico,nuevo.ciudad]);
        return results;
    }catch(err){
        return {error: "No se puede agregar al personal"}
    }
}

export const modificarCliente = async (modificado:Cliente) =>{
    try{
        const [results] = await conexion.query('UPDATE clientes SET nombre=?,direccion=?,telefono=?,correo_electronico=?,ciudad=? WHERE id=?',[modificado.nombre,modificado.direccion,modificado.telefono,modificado.correo_electronico,modificado.ciudad,modificado.id]);
        return results;
    }catch(err){
        return {error: "No se puede modificar"}
    }
}

export const borrarCliente = async (id:number) =>{
    try{
        const [results] = await conexion.query('DELETE FROM clientes WHERE id=?', [id]);
        return results;
    }catch(err){
        return{error: "No se puede borrar el cliente"}
    }
}