// src/services/comprasServices.ts

import { conexion } from './personalServices';
import { Compra, CompraNueva } from '../typesCompras';
import { compraSchema } from '../schema/compras.schema';

export const obtenerCompras = async () => {
    try {
        const [results] = await conexion.query('SELECT * FROM compras');
        return results;
    } catch (err) {
        return { error: "No se pueden obtener las compras" };
    }
};

export const encuentraCompra= async (id:number) =>{
    try{
        const identificador = {id: id}
        const validacion = compraSchema.safeParse(identificador);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('SELECT * FROM compras WHERE id = ? LIMIT 1',id);
        return results;
    }catch(err){
        return {error: "No se encuentra esa compra"};
    }
}

export const agregarCompra = async (nueva: CompraNueva) => {
    try {
        const validacion = compraSchema.safeParse(nueva);
        if (!validacion.success) {
            return { error: validacion.error };
        }
        const [results] = await conexion.query(
            `INSERT INTO compras (id_articulo, cantidad, precio, iva, subtotal, total, fecha_compra) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                nueva.id_articulo,
                nueva.cantidad,
                nueva.precio,
                nueva.iva,
                nueva.subtotal,
                nueva.total,
                nueva.fecha_compra
            ]
        );
        return results;
    } catch (err) {
        return { error: "No se puede agregar la compra" };
    }
};

export const modificarCompra = async (modificado: Compra) => {
    try {
        const [results] = await conexion.query(
            `UPDATE compras SET id_articulo=?, cantidad=?, precio=?, iva=?, subtotal=?,  total=?, fecha_compra=? WHERE id=?`,
            [
                modificado.id_articulo,
                modificado.cantidad,
                modificado.precio,
                modificado.iva,
                modificado.subtotal,
                modificado.total,
                modificado.fecha_compra,
                modificado.id
            ]
        );
        return results;
    } catch (err) {
        return { error: "No se puede modificar la compra" };
    }
};

export const borrarCompra = async (id: number) => {
    try {
        const [results] = await conexion.query('DELETE FROM compras WHERE id = ?', [id]);
        return results;
    } catch (err) {
        return { error: "No se puede eliminar la compra" };
    }
};
