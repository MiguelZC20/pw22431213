import { conexion } from './personalServices';
import { RegistroAgregar } from '../typesRegistro';
import { registroSchema } from '../schema/registro.schema';

export const obtenerRegistros = async () => {
    try {
        const [results] = await conexion.query('SELECT * FROM registro');
        return results;
    } catch (err) {
        return { error: "No se pueden obtener los registros" };
    }
}

export const encuentraRegistro= async (id:number) =>{
    try{
        const identificador = {id: id}
        const validacion = registroSchema.safeParse(identificador);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('SELECT * FROM registro WHERE id = ? LIMIT 1',id);
        return results;
    }catch(err){
        return {error: "No se encuentra ese registro"};
    }
}

export const agregarRegistro = async (nuevo: RegistroAgregar) => {
    try {
        const validacion = registroSchema.safeParse(nuevo);
        if (!validacion.success) {
            return { error: validacion.error };
        }
        const [results] = await conexion.query('INSERT INTO registro (id_personal, fecha, hora, movimiento) VALUES (?, ?, ?, ?)', [
            nuevo.id_personal,
            nuevo.fecha,
            nuevo.hora,
            nuevo.movimiento
        ]);
        return results;
    } catch (err) {
        return { error: "No se puede agregar el registro" };
    }
};

export const borrarRegistro = async (id: number) => {
    try {
        const [results] = await conexion.query('DELETE FROM registro WHERE id = ?', [id]);
        return results;
    } catch (err) {
        return { error: "No se puede borrar el registro" };
    }
};
