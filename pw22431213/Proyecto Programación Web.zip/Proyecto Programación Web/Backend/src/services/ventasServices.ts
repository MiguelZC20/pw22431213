import { conexion } from './personalServices';
import { Venta, VentaNueva } from '../typesVentas';
import { ventaSchema } from '../schema/ventas.schema';

export const obtenerVentas = async () => {
    try {
        const [results] = await conexion.query('SELECT * FROM ventas');
        return results;
    } catch (err) {
        return { error: "No se pueden obtener las ventas" };
    }
};
export const encuentraVenta= async (id:number) =>{
    try{
        const identificador = {id: id}
        const validacion = ventaSchema.safeParse(identificador);
        if(!validacion.success){
            return {error: validacion.error}
        }
        const [results] = await conexion.query('SELECT * FROM ventas WHERE id = ? LIMIT 1',id);
        return results;
    }catch(err){
        return {error: "No se encuentra esa venta"};
    }
}

export const agregarVenta = async (nueva: VentaNueva) => {
    try {
        const validacion = ventaSchema.safeParse(nueva);
        if (!validacion.success) {
            return { error: validacion.error };
        }
        const [results] = await conexion.query(
            `INSERT INTO ventas (id_articulo, id_cliente, cantidad, precio, iva, subtotal,total, fecha_venta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                nueva.id_articulo,
                nueva.id_cliente,
                nueva.cantidad,
                nueva.precio,
                nueva.iva,
                nueva.subtotal,
                nueva.total,
                nueva.fecha_venta
            ]
        );
        return results;
    } catch (err) {
        return { error: "No se puede agregar la venta" };
    }
};

export const modificarVenta = async (modificado: Venta) => {
    try {
        const [results] = await conexion.query(
            `UPDATE ventas SET id_articulo=?, id_cliente=?, cantidad=?, precio=?, iva=?, subtotal=?, total=?, fecha_venta=? WHERE id=?`,
            [
                modificado.id_articulo,
                modificado.id_cliente,
                modificado.cantidad,
                modificado.precio,
                modificado.iva,
                modificado.subtotal,
                modificado.total,
                modificado.fecha_venta,
                modificado.id
            ]
        );
        return results;
    } catch (err) {
        return { error: "No se puede modificar la venta" };
    }
};

export const borrarVenta = async (id: number) => {
    try {
        const [results] = await conexion.query('DELETE FROM ventas WHERE id = ?', [id]);
        return results;
    } catch (err) {
        return { error: "No se puede borrar la venta" };
    }
};
