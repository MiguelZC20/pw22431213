// src/types/typesCompras.ts

export interface Compra {
    id: number;
    id_articulo: number;
    cantidad: number;
    precio: number;
    iva: number;
    subtotal: number;
    total: number;
    fecha_compra: string;
}

export type CompraNueva = Omit<Compra,'id'>
