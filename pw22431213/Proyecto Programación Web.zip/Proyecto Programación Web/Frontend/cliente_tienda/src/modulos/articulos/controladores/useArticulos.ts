import { ref } from "vue"
import type { Articulo, articuloagregar } from "../interfaces/articulos-interface"
import articulosAPI from "../api/articulosAPI"

export const useArticulos = () => {
    const articulos = ref<Articulo[]>([])
    let mensaje = ref(0)

    // Obtener todos los artículos
    const traeArticulos = async () => {      
        const respuesta = await articulosAPI.get<Articulo[]>('/');
        articulos.value = respuesta.data
    };

    // Obtener un artículo por ID
    const traeArticuloId = async (id: number) => {
        const respuesta = await articulosAPI.get<Articulo[]>('/'+id);
        articulos.value = respuesta.data
    }

    // Agregar un nuevo artículo
    const agregarArticulo = async (articulo: articuloagregar) => {
        const respuesta = await articulosAPI.post('/',articulo)
        if(respuesta.data.affectedRows >=1){
            mensaje.value = 1
        }
    }

    // Actualizar un artículo existente
    const actualizarArticulo = async (articulo: Articulo) => {
        const respuesta = await articulosAPI.put('/',articulo)
        if(respuesta.data.affectedRows >=1){
            mensaje.value = 1
        }
    }

    // Borrar un artículo
    const borrarArticulo = async (articulo: Articulo) => {
        const respuesta = await articulosAPI.delete('/',{data: {id: articulo.id}})
        if(respuesta.data.fieldCount == 0){
            mensaje.value = 1
        }
    }

    return {
        articulos,
        mensaje,
        traeArticulos,
        traeArticuloId,
        agregarArticulo,
        actualizarArticulo,
        borrarArticulo
    }
}
