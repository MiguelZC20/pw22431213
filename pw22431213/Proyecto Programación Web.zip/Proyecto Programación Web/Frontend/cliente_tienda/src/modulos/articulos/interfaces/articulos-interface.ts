export interface Articulo {
    id: number;
    descripcion: string;
    precio: number;
    cantidad_en_almacen: number;
    fecha_caducidad: string;
}

export type articuloagregar = Omit<Articulo, 'id'>;
