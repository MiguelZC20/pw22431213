import { toTypedSchema } from "@vee-validate/zod";
import zod from 'zod';

export const ArticuloSchema = toTypedSchema(
  zod.object({
    descripcion: zod
      .string()
      .min(1, { message: 'Descripción requerida' })
      .max(200, { message: 'Máximo 200 caracteres' }),
    precio: zod
      .number({ message: 'Requerido' })
      .positive({ message: 'Debe ser un número positivo' }),
    cantidad_en_almacen: zod
      .number({ message: 'Requerido' })
      .int()
      .nonnegative({ message: 'Debe ser un número entero no negativo' }),
    fecha_caducidad: zod
      .string({ message: 'Requerido' })
      .regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'Formato AAAA-MM-DD requerido' }),
  })
)
