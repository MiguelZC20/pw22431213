<template>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h4>Agregar Artículo</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Artículo agregado con éxito
            </div>
            <div class="card-body">
                <Form :validation-schema="ArticuloSchema" @submit="onTodoBien">
                    <div class="mb-3">
                        Descripción
                        <Field name="descripcion" type="text" class="form-control" v-model="articulo.descripcion" />
                        <ErrorMessage name="descripcion" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Precio
                        <Field name="precio" type="number" class="form-control" v-model="articulo.precio" />
                        <ErrorMessage name="precio" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Cantidad en Almacén
                        <Field name="cantidad_en_almacen" type="number" class="form-control" v-model="articulo.cantidad_en_almacen" />
                        <ErrorMessage name="cantidad_en_almacen" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Fecha de Caducidad
                        <Field name="fecha_caducidad" type="date" class="form-control" v-model="articulo.fecha_caducidad" />
                        <ErrorMessage name="fecha_caducidad" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary" type="submit">Agregar</button>
                    </div>
                </Form>    
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import type { articuloagregar } from '../interfaces/articulos-interface';
import { useArticulos } from '../controladores/useArticulos'
const { agregarArticulo, mensaje } = useArticulos()
import { ArticuloSchema } from '../schemas/articulosSchema';
import { Field, Form, ErrorMessage } from 'vee-validate';

let articulo = ref<articuloagregar>({
    descripcion: '',
    precio: 0,
    cantidad_en_almacen: 0,
    fecha_caducidad: ''
})

const onTodoBien = async () => {
    await agregarArticulo(articulo.value);
}
</script>

<style scoped>
.errorValidacion{
    color: red;
    font-weight: bold;
}
</style>
