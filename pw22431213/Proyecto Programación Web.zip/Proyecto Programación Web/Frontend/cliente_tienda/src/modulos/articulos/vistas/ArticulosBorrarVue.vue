<template>
    <div class="container mt-5" v-if="articulos[0]">
        <div class="card">
            <div class="card-header">
                <h4>Borrar Artículo</h4>
            </div>

            <div class="alert alert-warning mt-3" role="alert">
                ¿Estás seguro de borrar este artículo?
                <i class="fa fa-warning"></i>
            </div>
            <div class="mb-3">
                ID del Artículo
                <input type="text" class="form-control" v-model="articulos[0].id" disabled />
            </div>
            <div class="mb-3">
                Descripción
                <input type="text" class="form-control" v-model="articulos[0].descripcion" disabled />
            </div>
            <div class="mb-3">
                Precio
                <input type="text" class="form-control" v-model="articulos[0].precio" disabled />
            </div>
            <div class="mb-3">
                Cantidad en Almacén
                <input type="text" class="form-control" v-model="articulos[0].cantidad_en_almacen" disabled />
            </div>
            <div class="mb-3">
                Fecha de Caducidad
                <input type="text" class="form-control" v-model="articulos[0].fecha_caducidad" disabled />
            </div>
            <div class="mb-3">
                <button class="btn btn-danger" @click="borrarArticulo(articulos[0])">Borrar</button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useArticulos } from '../controladores/useArticulos';
const { traeArticuloId, borrarArticulo, mensaje, articulos } = useArticulos();
let idArticulo = 0

const route = useRoute();
const routeRedirect = useRouter();

watch(
    () => mensaje.value,
    newId =>{
        routeRedirect.push('/articulos')
    }
)

onMounted(async () => {
    idArticulo = Number(route.params.id);
    await traeArticuloId(Number(idArticulo));
})

</script>

<style scoped>

</style>
