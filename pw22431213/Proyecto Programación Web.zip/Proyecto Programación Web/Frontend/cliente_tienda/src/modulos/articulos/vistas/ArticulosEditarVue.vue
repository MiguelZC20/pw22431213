<template>
    <div class="container mt-5" v-if="articulos[0]">
        <div class="card">
            <div class="card-header">
                <h4>Editar Artículo</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Datos actualizados con éxito
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Id
                    <input type="text" class="form-control" v-model="articulos[0].id" disabled />
                </div>
                <div class="mb-3">
                    Descripción
                    <input type="text" class="form-control" v-model="articulos[0].descripcion" />
                </div>
                <div class="mb-3">
                    Precio
                    <input type="number" class="form-control" v-model="articulos[0].precio" />
                </div>
                <div class="mb-3">
                    Cantidad en Almacén
                    <input type="number" class="form-control" v-model="articulos[0].cantidad_en_almacen" />
                </div>
                <div class="mb-3">
                    Fecha de Caducidad
                    <input type="date" class="form-control" v-model="articulos[0].fecha_caducidad" />
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary" @click="actualizarArticulo(articulos[0])">Actualizar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { useArticulos } from '../controladores/useArticulos';
const { traeArticuloId, actualizarArticulo, mensaje, articulos } = useArticulos();
let idArticulo = 0;
const route = useRoute();

onMounted(async () => {
    idArticulo = Number(route.params.id);
    await traeArticuloId(Number(idArticulo)); 
});
</script>

<style scoped>

</style>
