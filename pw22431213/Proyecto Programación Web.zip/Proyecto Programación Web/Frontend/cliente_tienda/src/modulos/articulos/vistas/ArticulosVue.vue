<template>
    <section>
        <div class="header">
            <h3>Artículos</h3>
            <RouterLink :to="{ path: '/articulos/agregar' }">
                <button class="btn btn-outline-primary btn-agregar">
                    Agregar <i class="fa fa-plus"></i>
                </button>
            </RouterLink>
        </div>

        <table class="tabla-articulos">
            <thead>
                <tr>
                    <th>Clave</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Cantidad en almacén</th>
                    <th>Fecha de caducidad</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>
                <tr v-if="articulos.length === 0">
                    <td class="centrado" colspan="6">Sin artículos registrados</td>
                </tr>
                <tr v-else v-for="(articulo, index) in articulos" :key="articulo.id">
                    <td>{{ articulo.id }}</td>
                    <td>{{ articulo.descripcion }}</td>
                    <td>{{ articulo.precio }}</td>
                    <td>{{ articulo.cantidad_en_almacen }}</td>
                    <td>{{ articulo.fecha_caducidad }}</td>
                    <td>
                        <div class="btn-group">
                            <RouterLink :to="{ path: `/articulos/${articulo.id}/editar` }" class="btn btn-editar">
                                <i class="fa fa-pencil"></i>
                            </RouterLink>
                            <RouterLink :to="{ path: `/articulos/${articulo.id}/borrar` }" class="btn btn-borrar">
                                <i class="fa fa-trash"></i>
                            </RouterLink>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </section>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { useArticulos } from '../controladores/useArticulos';
const { traeArticulos, articulos } = useArticulos();

onMounted(async () => await traeArticulos());
</script>

<style scoped>

section {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    background: #f9f9f9;
    border-radius: 10px;
    margin: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

.btn-agregar {
    padding: 10px 20px;
    font-weight: bold;
    color: #fff;
    background: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 16px;
}

.btn-agregar:hover {
    background: #0056b3;
    transform: scale(1.05);
}

.tabla-articulos {
    width: 90%;
    margin: 20px 0;
    border-collapse: collapse;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.tabla-articulos th {
    background: #007bff;
    color: #fff;
    padding: 10px;
    text-align: center;
}

.tabla-articulos td {
    padding: 10px;
    text-align: center;
    transition: background 0.3s ease;
}

.tabla-articulos tr:nth-child(even) {
    background: #f2f2f2;
}

.tabla-articulos tr:hover {
    background: #e9f7fa;
}

.btn-group {
    display: flex;
    gap: 10px;
    justify-content: center;
    align-items: center;
}

.btn {
    padding: 8px;
    text-decoration: none;
    font-weight: bold;
    color: #fff;
    border-radius: 5px;
    transition: background 0.3s ease, transform 0.2s ease;
}

.btn-editar {
    background: #18d218;
    color: #000;
}

.btn-editar:hover {
    background: #04952fe0;
    transform: scale(1.05);
}

.btn-borrar {
    background: #f44336;
    color: #fff;
}

.btn-borrar:hover {
    background: #d32f2f;
    transform: scale(1.05);
}

.centrado {
    text-align: center;
    font-weight: bold;
    font-size: 18px;
}
</style>
