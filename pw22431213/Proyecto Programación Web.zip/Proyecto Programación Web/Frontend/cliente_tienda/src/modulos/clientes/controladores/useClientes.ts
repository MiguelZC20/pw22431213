import { ref } from "vue";
import type { Cliente, clienteAgregar } from "../interfaces/clientes-interface";
import clientesAPI from "../api/clientesAPI";

export const useClientes = () => {
    const cliente = ref<Cliente[]>([]);
    let mensaje = ref(0);

    // Obtener todos los clientes
    const traeClientes = async () => {
        const respuesta = await clientesAPI.get<Cliente[]>('/');
        cliente.value = respuesta.data;
    };

    // Obtener un cliente específico por ID
    const traeClienteId = async (id: number) => {
        const respuesta = await clientesAPI.get<Cliente[]>('/'+id);
        cliente.value = respuesta.data;
    };

    // Agregar un cliente
    const agregarCliente = async (cliente: clienteAgregar) => {
        const respuesta = await clientesAPI.post('/', cliente);
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1;
        }
    };

    // Actualizar información del cliente
    const actualizarCliente = async (cliente: Cliente) => {
        const respuesta = await clientesAPI.put('/', cliente);
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1;
        }
    };

    // Borrar un cliente
    const borrarCliente = async (cliente: Cliente) => {
        const respuesta = await clientesAPI.delete('/', { data: { id: cliente.id } });
        if (respuesta.data.fieldCount == 0) {
            mensaje.value = 1;
        }
    };

    return {
        cliente,
        mensaje,
        traeClientes,
        traeClienteId,
        agregarCliente,
        actualizarCliente,
        borrarCliente
    };
};
