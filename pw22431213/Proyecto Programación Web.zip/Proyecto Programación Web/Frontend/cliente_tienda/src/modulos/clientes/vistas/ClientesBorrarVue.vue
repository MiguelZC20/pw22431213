<template>
    <div class="container mt-5" v-if="cliente[0]">
        <div class="card">
            <div class="card-header">
                <h4>Borrar Cliente</h4>
            </div>

            <div class="alert alert-warning mt-3" role="alert">
                ¿Estás seguro de borrar este cliente?
                <i class="fa fa-warning"></i>
            </div>

            <div class="mb-3">
                <label>Nombre</label>
                <input type="text" class="form-control" :value="cliente[0].nombre" disabled />
            </div>
            <div class="mb-3">
                <label>Teléfono</label>
                <input type="text" class="form-control" :value="cliente[0].telefono" disabled />
            </div>

            <div class="mb-3">
                <button class="btn btn-danger" @click="borrarCliente(cliente[0])">Borrar</button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useClientes } from '../controladores/useClientes';
const { traeClienteId, borrarCliente, mensaje, cliente } = useClientes();
let idCliente = 0

const route = useRoute();
const routeRedirect = useRouter();

watch(
    () => mensaje.value,
    newId =>{
        routeRedirect.push('/clientes')
    }
)

onMounted(async () => {
    idCliente = Number(route.params.id);
    await traeClienteId(Number(idCliente));
});


// watch(mensaje, (newMensaje) => {
//     if (newMensaje === 1) {
//         router.push('/clientes');
//     }
// });

</script>

<style scoped>

</style>
