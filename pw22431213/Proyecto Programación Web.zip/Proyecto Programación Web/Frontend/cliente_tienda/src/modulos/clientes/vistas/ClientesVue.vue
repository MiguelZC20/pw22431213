<template>
    <section>
        <div class="header">
            <h3>Clientes</h3>
            <RouterLink :to="{ path: '/clientes/agregar' }">
                <button class="btn btn-outline-primary btn-agregar">
                    Agregar <i class="fa fa-plus"></i>
                </button>
            </RouterLink>
        </div>

        <table class="tabla-clientes">
            <thead>
                <tr>
                    <th>Clave</th>
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Teléfono</th>
                    <th>Correo</th>
                    <th>Ciudad</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>
                <tr v-if="cliente.length == 0">
                    <td class="centrado" colspan="7">Sin clientes registrados</td>
                </tr>
                <tr v-else v-for="(cliente, index) in cliente" :key="cliente.id">
                    <td>{{ cliente.id }}</td>
                    <td>{{ cliente.nombre }}</td>
                    <td>{{ cliente.direccion }}</td>
                    <td>{{ cliente.telefono }}</td>
                    <td>{{ cliente.correo_electronico }}</td>
                    <td>{{ cliente.ciudad }}</td>
                    <td>
                        <div class="btn-group">
                            <RouterLink :to="{ path: `/clientes/${cliente.id}/editar` }" class="btn btn-editar">
                                <i class="fa fa-pencil"></i>
                            </RouterLink>
                            <RouterLink :to="{ path: `/clientes/${cliente.id}/borrar` }" class="btn btn-borrar">
                                <i class="fa fa-trash"></i>
                            </RouterLink>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </section>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { useClientes } from '../controladores/useClientes';

const { traeClientes, cliente } = useClientes();

onMounted(async () => await traeClientes());
</script>

<style scoped>

section {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    background: #f9f9f9;
    border-radius: 10px;
    margin: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}


.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}


.btn-agregar {
    padding: 10px 20px;
    font-weight: bold;
    color: #fff;
    background: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 16px;
}

.btn-agregar:hover {
    background: #0056b3;
    transform: scale(1.05);
}


.tabla-clientes {
    width: 90%;
    margin: 20px 0;
    border-collapse: collapse;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.tabla-clientes th {
    background: #007bff;
    color: #fff;
    padding: 10px;
    text-align: center;
}

.tabla-clientes td {
    padding: 10px;
    text-align: center;
    transition: background 0.3s;
}

.tabla-clientes tr:nth-child(even) {
    background: #f2f2f2;
}


.tabla-clientes tr:hover {
    background: #e9f7fa;
}


.btn-group {
    display: flex;
    gap: 10px;
    justify-content: center;
    align-items: center;
}

.btn {
    padding: 8px;
    text-decoration: none;
    font-weight: bold;
    color: #fff;
    border-radius: 5px;
    transition: background 0.3s ease, transform 0.2s ease;
}

.btn-editar {
    background: #18d218;
    color: #000;
    display: inline-block;
    text-align: center;
}

.btn-editar:hover {
    background: #04952fe0;
    transform: scale(1.05);
}

.btn-borrar {
    background: #f44336;
    color: #fff;
}

.btn-borrar:hover {
    background: #d32f2f;
    transform: scale(1.05);
}

.centrado {
    text-align: center;
    font-weight: bold;
    font-size: 18px;
}
</style>
