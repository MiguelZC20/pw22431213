import { ref } from "vue";
import type { Compra, compraAgregar } from "../interfaces/compras-interface";
import comprasAPI from "../api/comprasAPI";

export const useCompras = () => {
    const compras = ref<Compra[]>([]);
    let mensaje = ref(0);

    // Obtener todas las compras
    const traeCompras = async () => {
        const respuesta = await comprasAPI.get<Compra[]>('/');
        compras.value = respuesta.data;
    };

    // Obtener una compra específica por ID
    const traeCompraId = async (id: number) => {
        const respuesta = await comprasAPI.get<Compra[]>('/' + id);
        compras.value = respuesta.data;
    };

    // Agregar una compra
    const agregarCompra = async (compra: compraAgregar) => {
        const respuesta = await comprasAPI.post('/', compra);
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1;
        }
    };

    // Actualizar información de una compra
    const actualizarCompra = async (compra: Compra) => {
        const respuesta = await comprasAPI.put('/', compra);
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1;
        }
    };

    // Borrar una compra
    const borrarCompra = async (compra: Compra) => {
        const respuesta = await comprasAPI.delete('/', { data: { id: compra.id } });
        if (respuesta.data.fieldCount === 0) {
            mensaje.value = 1;
        }
    };

    return {
        compras,
        mensaje,
        traeCompras,
        traeCompraId,
        agregarCompra,
        actualizarCompra,
        borrarCompra
    };
};
