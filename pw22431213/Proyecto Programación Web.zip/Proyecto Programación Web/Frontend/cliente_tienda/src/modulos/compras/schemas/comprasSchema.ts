import { toTypedSchema } from "@vee-validate/zod";
import zod from 'zod';

export const ComprasSchema = toTypedSchema(
    zod.object({
        id: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
        id_articulo: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
        cantidad: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un número positivo' }),
        precio: zod.number({ message: 'Requerido' }).positive({ message: 'Un número positivo' }),
        iva: zod.number({ message: 'Requerido' }).min(0, { message: 'El IVA no puede ser negativo' }).max(100, { message: 'El IVA no puede ser mayor a 100' }),
        subtotal: zod.number({ message: 'Requerido' }).positive({ message: 'El subtotal debe ser un número positivo' }),
        total: zod.number({ message: 'Requerido' }).positive({ message: 'El total debe ser un número positivo' }),
        fecha_compra: zod.string().min(1, { message: 'Fecha de compra requerida' }).max(20, { message: 'Máximo 20 caracteres' }),
    }).or(
        zod.object({
            id_articulo: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
            cantidad: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un número positivo' }),
            precio: zod.number({ message: 'Requerido' }).positive({ message: 'Un número positivo' }),
            iva: zod.number({ message: 'Requerido' }).min(0, { message: 'El IVA no puede ser negativo' }).max(100, { message: 'El IVA no puede ser mayor a 100' }),
            subtotal: zod.number({ message: 'Requerido' }).positive({ message: 'El subtotal debe ser un número positivo' }),
            total: zod.number({ message: 'Requerido' }).positive({ message: 'El total debe ser un número positivo' }),
            fecha_compra: zod.string().min(1, { message: 'Fecha de compra requerida' }).max(20, { message: 'Máximo 20 caracteres' }),
        })
    )
);
