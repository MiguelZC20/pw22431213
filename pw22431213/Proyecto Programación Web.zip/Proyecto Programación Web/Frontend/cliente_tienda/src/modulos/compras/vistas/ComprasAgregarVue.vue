<template>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h4>Agregar Compra</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Datos agregados con éxito
            </div>
            <div class="card-body">
                <Form :validation-schema="ComprasSchema" @submit="onTodoBien">
                    <div class="mb-3">
                        ID Artículo
                        <Field name="id_articulo" type="number" class="form-control" v-model="compra.id_articulo" />
                        <ErrorMessage name="id_articulo" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Cantidad
                        <Field name="cantidad" type="number" class="form-control" v-model="compra.cantidad" />
                        <ErrorMessage name="cantidad" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Precio
                        <Field name="precio" type="number" class="form-control" v-model="compra.precio" />
                        <ErrorMessage name="precio" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        IVA
                        <Field name="iva" type="number" class="form-control" v-model="compra.iva" />
                        <ErrorMessage name="iva" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Subtotal
                        <Field name="subtotal" type="number" class="form-control" v-model="compra.subtotal" />
                        <ErrorMessage name="subtotal" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Total
                        <Field name="total" type="number" class="form-control" v-model="compra.total" />
                        <ErrorMessage name="total" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Fecha de Compra
                        <Field name="fecha_compra" type="date" class="form-control" v-model="compra.fecha_compra" />
                        <ErrorMessage name="fecha_compra" class="errorValidacion" />
                    </div>
                    <button class="btn btn-primary" type="submit">Agregar Compra</button>
                </Form>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import type { compraAgregar } from '../interfaces/compras-interface';
import { useCompras } from '../controladores/useCompras';
const { agregarCompra, mensaje } = useCompras();
import { ComprasSchema } from '../schemas/comprasSchema';  
import { Field, Form, ErrorMessage } from 'vee-validate';


let compra = ref<compraAgregar>({
    id_articulo: 0,
    cantidad: 0,
    precio: 0,
    iva: 0,
    subtotal: 0,
    total: 0,
    fecha_compra: '' 
});

const onTodoBien = async () => {
    await agregarCompra(compra.value);
}
</script>

<style scoped>
.errorValidacion {
    color: red;
    font-weight: bold;
}
</style>
