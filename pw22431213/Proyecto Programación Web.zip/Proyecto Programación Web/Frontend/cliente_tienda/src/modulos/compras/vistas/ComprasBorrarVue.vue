<template>
    <div class="container mt-5" v-if="compras[0]">
        <div class="card">
            <div class="card-header">
                <h4>Borrar Compra</h4>
            </div>
            <div class="alert alert-warning mt-3" role="alert">
                ¿Estás seguro de borrar esta compra?
                <i class="fa fa-warning"></i>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Id de compra
                    <input type="text" class="form-control" v-model="compras[0].id" disabled>
                </div>
                <div class="mb-3">
                    ID Artículo
                    <input type="text" class="form-control" v-model="compras[0].id_articulo" disabled>
                </div>
                <div class="mb-3">
                    Cantidad
                    <input type="text" class="form-control" v-model="compras[0].cantidad" disabled>
                </div>
                <div class="mb-3">
                    Precio
                    <input type="text" class="form-control" v-model="compras[0].precio" disabled>
                </div>
                <div class="mb-3">
                    IVA
                    <input type="text" class="form-control" v-model="compras[0].iva" disabled>
                </div>
                <div class="mb-3">
                    Subtotal
                    <input type="text" class="form-control" v-model="compras[0].subtotal" disabled>
                </div>
                <div class="mb-3">
                    Total
                    <input type="text" class="form-control" v-model="compras[0].total" disabled>
                </div>
                <div class="mb-3">
                    Fecha de Compra
                    <input type="text" class="form-control" v-model="compras[0].fecha_compra" disabled>
                </div>
                <div class="mb-3">
                    <button class="btn btn-danger" @click="borrarCompra(compras[0])">Borrar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useCompras } from '../controladores/useCompras';
const { traeCompraId, borrarCompra, mensaje, compras } = useCompras();
let idCompra = 0

// Para los parámetros de la URL
const route = useRoute()
// Para redirigir a otra página
const routeRedirect = useRouter()
// Observador - Watch
watch(
    () => mensaje.value,
    newId => {
        routeRedirect.push('/compras')
    }
)

onMounted(async () => {
    idCompra = Number(route.params.id);
    await traeCompraId(idCompra)
})

</script>

<style scoped>

</style>
