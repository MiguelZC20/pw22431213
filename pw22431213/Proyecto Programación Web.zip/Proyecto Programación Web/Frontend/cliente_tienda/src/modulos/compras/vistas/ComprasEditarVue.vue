<template>
    <div class="container mt-5" v-if="compras[0]">
        <div class="card">
            <div class="card-header">
                <h4>Editar Compra</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Datos actualizados con éxito
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Id
                    <input type="text" class="form-control" v-model="compras[0].id" disabled />
                </div>
                <div class="mb-3">
                    ID Artículo
                    <input type="text" class="form-control" v-model="compras[0].id_articulo" />
                </div>
                <div class="mb-3">
                    Cantidad
                    <input type="number" class="form-control" v-model="compras[0].cantidad" />
                </div>
                <div class="mb-3">
                    Precio
                    <input type="number" class="form-control" v-model="compras[0].precio" />
                </div>
                <div class="mb-3">
                    IVA 
                    <input type="number" class="form-control" v-model="compras[0].iva" />
                </div>
                <div class="mb-3">
                    Subtotal
                    <input type="number" class="form-control" v-model="compras[0].subtotal" />
                </div>
                <div class="mb-3">
                    Total
                    <input type="number" class="form-control" v-model="compras[0].total" />
                </div>
                <div class="mb-3">
                    Fecha de Compra
                    <input type="date" class="form-control" v-model="compras[0].fechaCompra" />
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary" @click="actualizarCompra(compras[0])">Actualizar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { useCompras } from '../controladores/useCompras';

const { traeCompraId, actualizarCompra, mensaje, compras } = useCompras();
let idCompra = 0;
const route = useRoute();

onMounted(async () => {
    idCompra = Number(route.params.id);
    await traeCompraId(idCompra);
});

</script>

<style scoped>
/* Aquí puedes agregar estilos personalizados */
</style>
