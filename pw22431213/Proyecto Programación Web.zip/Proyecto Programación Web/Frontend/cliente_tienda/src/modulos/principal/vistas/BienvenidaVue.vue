<template>
    <div class="contenedor">
        <div class="bienvenida">
            <h1>Bienvenido a la Tienda</h1>
        </div>
    </div>
</template>

<style scoped>

.contenedor {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: linear-gradient(135deg, #007bff, #00b4d8);
    color: #fff;
    font-family: 'Arial', sans-serif;
}

.bienvenida {
    text-align: center;
    background: rgba(255, 255, 255, 0.1);
    padding: 30px 50px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    animation: aparecer 1s ease-out;
}

.bienvenida h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    color: #fff;
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);
}






/* Animación */
@keyframes aparecer {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}
</style>
