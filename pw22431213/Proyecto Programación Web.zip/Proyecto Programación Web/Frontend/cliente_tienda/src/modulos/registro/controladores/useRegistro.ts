import { ref } from "vue";
import type { Registro, RegistroAgregar } from "../interfaces/registro-interface"; 
import registroAPI from "../api/registroAPI"; 

export const useRegistro = () => {
    const registros = ref<Registro[]>([]); 
    let mensaje = ref(0); 

    // Trae todos los registros
    const traeRegistros = async () => {
        const respuesta = await registroAPI.get<Registro[]>('/'); 
        registros.value = respuesta.data; 
    };

    // Trae un registro por su ID
    const traeRegistroId = async (id: number) => {
        const respuesta = await registroAPI.get<Registro>('/' + id); 
        registros.value = [respuesta.data]; 
    };

    // Agrega un nuevo registro
    const agregarRegistro = async (registro: RegistroAgregar) => {
        const respuesta = await registroAPI.post('/', registro); 
        if (respuesta.data.affectedRows >= 1) { 
            mensaje.value = 1; 
        }
    };

    // Actualiza un registro existente
    const actualizarRegistro = async (registro: Registro) => {
        const respuesta = await registroAPI.put('/', registro); 
        if (respuesta.data.affectedRows >= 1) { 
            mensaje.value = 1; 
        }
    };

    // Elimina un registro
    const borrarRegistro = async (registro: Registro) => {
        const respuesta = await registroAPI.delete('/', { data: { id: registro.id } }); 
        if (respuesta.data.fieldCount == 0) { 
            mensaje.value = 1; 
        }
    };

    return {
        registros,
        mensaje,
        traeRegistros,
        traeRegistroId,
        agregarRegistro,
        actualizarRegistro,
        borrarRegistro
    };
};
