import { toTypedSchema } from "@vee-validate/zod";
import zod from 'zod';

export const RegistroSchema = toTypedSchema(
    zod.object({
        id: zod.number({ message: 'ID del registro requerido' }).int().positive({ message: 'El ID debe ser un entero positivo' }),
        id_personal: zod.number({ message: 'ID del personal requerido' }).int().positive({ message: 'El ID del personal debe ser un entero positivo' }),
        fecha: zod.string({ message: 'Fecha requerida' }).min(10, { message: 'Formato de fecha incorrecto' }), 
        hora: zod.string({ message: 'Hora requerida' }).min(5, { message: 'Formato de hora incorrecto' }), 
        movimiento: zod.enum(['entrada', 'salida'], { message: 'Movimiento debe ser "entrada" o "salida"' }) 
    }).or(
        zod.object({
            id_personal: zod.number({ message: 'ID del personal requerido' }).int().positive({ message: 'El ID del personal debe ser un entero positivo' }),
            fecha: zod.string({ message: 'Fecha requerida' }).min(10, { message: 'Formato de fecha incorrecto' }),
            hora: zod.string({ message: 'Hora requerida' }).min(5, { message: 'Formato de hora incorrecto' }),
            movimiento: zod.enum(['entrada', 'salida'], { message: 'Movimiento debe ser "entrada" o "salida"' })
        })
    )
);
