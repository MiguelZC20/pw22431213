<template>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h4>Agregar Registro</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Registro agregado con éxito
            </div>
            <div class="card-body">
                <Form :validation-schema="RegistroSchema" @submit="onTodoBien">
                    <div class="mb-3">
                        Id del Personal
                        <Field name="id_personal" type="number" class="form-control" v-model="registro.id_personal" />
                        <ErrorMessage name="id_personal" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Fecha
                        <Field name="fecha" type="date" class="form-control" v-model="registro.fecha" />
                        <ErrorMessage name="fecha" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Hora
                        <Field name="hora" type="time" class="form-control" v-model="registro.hora" />
                        <ErrorMessage name="hora" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Movimiento
                        <Field name="movimiento" as="select" class="form-control" v-model="registro.movimiento">
                            <option value="entrada">Entrada</option>
                            <option value="salida">Salida</option>
                        </Field>
                        <ErrorMessage name="movimiento" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary" type="submit">Agregar</button>
                    </div>
                </Form>    
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import type { RegistroAgregar } from '../interfaces/registro-interface';
import { useRegistro } from '../controladores/useRegistro';
const { agregarRegistro, mensaje } = useRegistro();
import { RegistroSchema } from '../schemas/registroSchema';
import { Field, Form, ErrorMessage } from 'vee-validate';

let registro = ref<RegistroAgregar>({
    id_personal: 0,  
    fecha: '',
    hora: '',
    movimiento: '',
});

const onTodoBien = async () => {
    await agregarRegistro(registro.value);
    console.log()
}
</script>

<style scoped>
.errorValidacion {
    color: red;
    font-weight: bold;
}
</style>
