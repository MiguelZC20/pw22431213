<template>
    <div class="container mt-5" v-if="registros[0]">
        <div class="card">
            <div class="card-header">
                <h4>Borrar Registro</h4>
            </div>

            <div class="alert alert-warning mt-3" role="alert">
                ¿Estás seguro de borrar este registro?
                <i class="fa fa-warning"></i>
            </div>

            <div class="mb-3">
                <label>ID del Personal</label>
                <input type="text" class="form-control" :value="registros[0].id_personal" disabled />
            </div>
            <div class="mb-3">
                <label>Fecha</label>
                <input type="text" class="form-control" :value="registros[0].fecha" disabled />
            </div>
            <div class="mb-3">
                <label>Hora</label>
                <input type="text" class="form-control" :value="registros[0].hora" disabled />
            </div>
            <div class="mb-3">
                <label>Movimiento</label>
                <input type="text" class="form-control" :value="registros[0].movimiento" disabled />
            </div>

            <div class="mb-3">
                <button class="btn btn-danger" @click="borrarRegistro(registros[0])">Borrar</button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useRegistro } from '../controladores/useRegistro';
const { traeRegistroId, borrarRegistro, mensaje, registros } = useRegistro();
let idRegistro = 0

const route = useRoute();
const routeRedirect = useRouter();

watch(
    () => mensaje.value,
    newId =>{
        routeRedirect.push('/registro')
    }
)

onMounted(async () => {
    idRegistro = Number(route.params.id);
    await traeRegistroId(Number(idRegistro)); 
})


</script>

<style scoped>
/* Aquí puedes agregar estilos personalizados si lo deseas */
</style>
