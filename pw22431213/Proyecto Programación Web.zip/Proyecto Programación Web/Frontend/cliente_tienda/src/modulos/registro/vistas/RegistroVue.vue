<template>
    <section>
        <div class="header">
            <h3>Registros</h3>
            <RouterLink :to="{ path: '/registro/agregar' }">
                <button class="btn btn-outline-primary btn-agregar">
                    Agregar <i class="fa fa-plus"></i>
                </button>
            </RouterLink>
        </div>

        <table class="tabla-registros">
            <thead>
                <tr>
                    <th>ID del Personal</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Movimiento</th>
                </tr>
            </thead>

            <tbody>
                <tr v-if="registros.length === 0">
                    <td class="centrado" colspan="5">Sin registros disponibles</td>
                </tr>

                <tr v-else v-for="(registro, index) in registros" :key="registro.id">
                    <td>{{ registro.id_personal }}</td>
                    <td>{{ registro.fecha }}</td>
                    <td>{{ registro.hora }}</td>
                    <td>{{ registro.movimiento }}</td>
                    <td class="centrado">
                        <!-- <div class="btn-group">
                            <RouterLink :to="{ path: `/registro/${registro.id}/editar` }" class="btn btn-editar">
                                <i class="fa fa-pencil"></i>
                            </RouterLink>
                            <RouterLink :to="{ path: `/registro/${registro.id}/borrar` }" class="btn btn-borrar">
                                <i class="fa fa-trash"></i>
                            </RouterLink>
                        </div> -->
                    </td>
                </tr>
            </tbody>
        </table>
    </section>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { useRegistro } from '../controladores/useRegistro';

const { registros, traeRegistros } = useRegistro();

onMounted(async () => {
    await traeRegistros();
});
</script>

<style scoped>

section {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    background: #f5f5f5;
    border-radius: 10px;
    margin: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

.btn-agregar {
    padding: 10px 20px;
    font-weight: bold;
    color: #fff;
    background: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 16px;
}

.btn-agregar:hover {
    background: #0056b3;
    transform: scale(1.05);
}

.tabla-registros {
    width: 90%;
    margin: 20px;
    border-collapse: collapse;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.tabla-registros th {
    background: #007bff;
    color: #fff;
    padding: 10px;
    text-align: center;
}

.tabla-registros td {
    padding: 10px;
    text-align: center;
    transition: background 0.3s ease;
}

.tabla-registros tr:nth-child(even) {
    background: #f2f2f2;
}

.tabla-registros tr:hover {
    background: #e9f7fa;
}

.btn-group {
    display: flex;
    justify-content: center;
    gap: 10px;
    align-items: center;
}

.btn {
    padding: 8px;
    text-decoration: none;
    font-weight: bold;
    color: #fff;
    border-radius: 5px;
    transition: background 0.3s ease, transform 0.2s ease;
}

.btn-borrar {
    background: #f44336;
    color: #fff;
}

.btn-borrar:hover {
    background: #d32f2f;
    transform: scale(1.05);
}

.centrado {
    text-align: center;
    font-weight: bold;
    font-size: 18px;
}
</style>
