import { ref } from "vue"
import type { Venta, ventaAgregar } from "../interfaces/ventas-interface"
import ventasAPI from "../api/ventasAPI"

export const useVentas = () => {
    const ventas = ref<Venta[]>([]) 
    let mensaje = ref(0) 

    // Función para obtener todas las ventas
    const traeVentas = async () => {
        const respuesta = await ventasAPI.get<Venta[]>('/')
        ventas.value = respuesta.data
    }

    // Función para obtener una venta por su id
    const traeVentaId = async (id: number) => {
        const respuesta = await ventasAPI.get<Venta[]>('/' + id)
        ventas.value = respuesta.data
    }

    // Función para agregar una nueva venta
    const agregarVenta = async (venta: ventaAgregar) => {
        const respuesta = await ventasAPI.post('/', venta)
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1 
        }
    }

    // Función para actualizar una venta
    const actualizarVenta = async (venta: Venta) => {
        const respuesta = await ventasAPI.put('/', venta)
        if (respuesta.data.affectedRows >= 1) {
            mensaje.value = 1 
        }
    }

    // Función para borrar una venta
    const borrarVenta = async (venta: Venta) => {
        const respuesta = await ventasAPI.delete('/', { data: { id: venta.id } })
        if (respuesta.data.fieldCount === 0) {
            mensaje.value = 1 
        }
    }

    return {
        ventas,
        mensaje,
        traeVentas,
        traeVentaId,
        agregarVenta,
        actualizarVenta,
        borrarVenta
    }
}
