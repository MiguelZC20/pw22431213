import { toTypedSchema } from "@vee-validate/zod";
import zod from 'zod';

export const VentaSchema = toTypedSchema(
    zod.object({
        id: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
        id_articulo: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
        id_cliente: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
        cantidad: zod.number({ message: 'Requerido' }).int().positive({ message: 'Debe ser un número entero positivo' }),
        precio: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
        iva: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
        subtotal: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
        total: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
        fecha_venta: zod.string({ message: 'Fecha requerida' }).regex(
            /^\d{4}-\d{2}-\d{2}$/, { message: 'Formato de fecha incorrecto. Use YYYY-MM-DD' }
        )
    }).or(
        zod.object({
            id_articulo: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
            id_cliente: zod.number({ message: 'Requerido' }).int().positive({ message: 'Un entero positivo' }),
            cantidad: zod.number({ message: 'Requerido' }).int().positive({ message: 'Debe ser un número entero positivo' }),
            precio: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
            iva: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
            subtotal: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
            total: zod.number({ message: 'Requerido' }).positive({ message: 'Debe ser un número positivo' }),
            fecha_venta: zod.string({ message: 'Fecha requerida' }).regex(
                /^\d{4}-\d{2}-\d{2}$/, { message: 'Formato de fecha incorrecto. Use YYYY-MM-DD' }
            )
        })
    )
);
