<template>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h4>Agregar Venta</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Venta agregada con éxito
            </div>
            <div class="card-body">
                <Form :validation-schema="VentaSchema" @submit="onTodoBien">
                    <div class="mb-3">
                        ID Artículo
                        <Field name="id_articulo" type="number" class="form-control" v-model="venta.id_articulo" />
                        <ErrorMessage name="id_articulo" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        ID Cliente
                        <Field name="id_cliente" type="number" class="form-control" v-model="venta.id_cliente" />
                        <ErrorMessage name="id_cliente" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Cantidad
                        <Field name="cantidad" type="number" class="form-control" v-model="venta.cantidad" />
                        <ErrorMessage name="cantidad" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Precio
                        <Field name="precio" type="number" class="form-control" v-model="venta.precio" />
                        <ErrorMessage name="precio" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        IVA
                        <Field name="iva" type="number" class="form-control" v-model="venta.iva" />
                        <ErrorMessage name="iva" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Subtotal
                        <Field name="subtotal" type="number" class="form-control" v-model="venta.subtotal" />
                        <ErrorMessage name="subtotal" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Total
                        <Field name="total" type="number" class="form-control" v-model="venta.total" />
                        <ErrorMessage name="total" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        Fecha de Venta
                        <Field name="fecha_venta" type="date" class="form-control" v-model="venta.fecha_venta" />
                        <ErrorMessage name="fecha_venta" class="errorValidacion" />
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary" type="submit">Agregar Venta</button>
                    </div>
                </Form>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import type { ventaAgregar } from '../interfaces/ventas-interface';
import { useVentas } from '../controladores/useVentas';
const { agregarVenta, mensaje } = useVentas();
import { VentaSchema } from '../schemas/ventasSchema';
import { Field, Form, ErrorMessage } from 'vee-validate';


let venta = ref<ventaAgregar>({
    id_articulo: 0,   
    id_cliente: 0,    
    cantidad: 0,
    precio: 0,
    iva: 0,
    subtotal: 0,
    total: 0,
    fecha_venta: ''
})

const onTodoBien = async () => {
    await agregarVenta(venta.value);
}
</script>

<style scoped>
.errorValidacion {
    color: red;
    font-weight: bold;
}
</style>
