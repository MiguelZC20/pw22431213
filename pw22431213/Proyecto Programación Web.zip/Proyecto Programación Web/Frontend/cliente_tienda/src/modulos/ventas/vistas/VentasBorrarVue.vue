<template>
    <div class="container mt-5" v-if="ventas[0]">
        <div class="card">
            <div class="card-header">
                <h4>Borrar Venta</h4>
            </div>
            <div class="alert alert-warning" role="alert">
                ¿Seguro de borrar esta venta?
                <i class="fa fa-warning"></i>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Id de Venta
                    <input type="text" class="form-control" v-model="ventas[0].id" disabled>
                </div>
                <div class="mb-3">
                    Id Artículo
                    <input type="text" class="form-control" v-model="ventas[0].id_articulo" disabled>
                </div>
                <div class="mb-3">
                    Id Cliente
                    <input type="text" class="form-control" v-model="ventas[0].id_cliente" disabled>
                </div>
                <div class="mb-3">
                    Cantidad
                    <input type="text" class="form-control" v-model="ventas[0].cantidad" disabled>
                </div>
                <div class="mb-3">
                    Precio
                    <input type="text" class="form-control" v-model="ventas[0].precio" disabled>
                </div>
                <div class="mb-3">
                    IVA
                    <input type="text" class="form-control" v-model="ventas[0].iva" disabled>
                </div>
                <div class="mb-3">
                    Subtotal
                    <input type="text" class="form-control" v-model="ventas[0].subtotal" disabled>
                </div>
                <div class="mb-3">
                    Total
                    <input type="text" class="form-control" v-model="ventas[0].total" disabled>
                </div>
                <div class="mb-3">
                    Fecha de Venta
                    <input type="text" class="form-control" v-model="ventas[0].fecha_venta" disabled>
                </div>
                <div class="mb-3">
                    <button class="btn btn-danger" @click="borrarVenta(ventas[0])">Borrar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router'
import { useVentas } from '../controladores/useVentas'
const { traeVentaId, borrarVenta, mensaje, ventas } = useVentas()
let idVenta = 0
// Para los parámetros de la URL
const route = useRoute()
// Para redirigir a otra página
const routeRedirect = useRouter()
// Observador - Watch
watch(
    () => mensaje.value,
    newId => {
        routeRedirect.push('/ventas')
    }
)

onMounted(async () => {
    idVenta = Number(route.params.id);
    await traeVentaId(idVenta)
})
</script>

<style scoped>

</style>
