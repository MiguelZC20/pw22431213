<template>
    <div class="container mt-5" v-if="ventas[0]">
        <div class="card">
            <div class="card-header">
                <h4>Editar Venta</h4>
            </div>
            <div v-if="mensaje == 1" class="alert alert-success" role="alert">
                Datos actualizados con éxito
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Id de Venta
                    <input type="text" class="form-control" v-model="ventas[0].id" disabled>
                </div>
                <div class="mb-3">
                    Id Artículo
                    <input type="text" class="form-control" v-model="ventas[0].id_articulo">
                </div>
                <div class="mb-3">
                    Id Cliente
                    <input type="text" class="form-control" v-model="ventas[0].id_cliente">
                </div>
                <div class="mb-3">
                    Cantidad
                    <input type="text" class="form-control" v-model="ventas[0].cantidad">
                </div>
                <div class="mb-3">
                    Precio
                    <input type="text" class="form-control" v-model="ventas[0].precio">
                </div>
                <div class="mb-3">
                    IVA
                    <input type="text" class="form-control" v-model="ventas[0].iva">
                </div>
                <div class="mb-3">
                    Subtotal
                    <input type="text" class="form-control" v-model="ventas[0].subtotal">
                </div>
                <div class="mb-3">
                    Total
                    <input type="text" class="form-control" v-model="ventas[0].total">
                </div>
                <div class="mb-3">
                    Fecha de Venta
                    <input type="text" class="form-control" v-model="ventas[0].fecha_venta">
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary" @click="actualizarVenta(ventas[0])">Actualizar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router'
import { useVentas } from '../controladores/useVentas'
const { traeVentaId, actualizarVenta, mensaje, ventas } = useVentas()
let idVenta = 0
const route = useRoute()

onMounted(async () => {
    idVenta = Number(route.params.id);
    await traeVentaId(idVenta)
})
</script>

<style scoped>

</style>
