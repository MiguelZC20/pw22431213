import PersonalAgregarVue from '@/modulos/personal/vistas/PersonalAgregarVue.vue'
import PersonalBorrarVue from '@/modulos/personal/vistas/PersonalBorrarVue.vue'
import PersonalEditarVue from '@/modulos/personal/vistas/PersonalEditarVue.vue'
import PersonalVue from '@/modulos/personal/vistas/PersonalVue.vue'

import ClientesVue from '@/modulos/clientes/vistas/ClientesVue.vue';
import ClientesAgregarVue from '@/modulos/clientes/vistas/ClientesAgregarVue.vue';
import ClientesEditarVue from '@/modulos/clientes/vistas/ClientesEditarVue.vue';
import ClientesBorrarVue from '@/modulos/clientes/vistas/ClientesBorrarVue.vue';

import ArticulosVue from '@/modulos/articulos/vistas/ArticulosVue.vue';
import ArticulosAgregarVue from '@/modulos/articulos/vistas/ArticulosAgregarVue.vue'
import ArticulosEditarVue from '@/modulos/articulos/vistas/ArticulosEditarVue.vue';
import ArticulosBorrarVue from '@/modulos/articulos/vistas/ArticulosBorrarVue.vue';

import VentasVue from '@/modulos/ventas/vistas/VentasVue.vue';
import VentasAgregarVue from '@/modulos/ventas/vistas/VentasAgregarVue.vue';
import VentasEditarVue from '@/modulos/ventas/vistas/VentasEditarVue.vue';
import VentasBorrarVue from '@/modulos/ventas/vistas/VentasBorrarVue.vue';

import RegistroVue from '@/modulos/registro/vistas/RegistroVue.vue';
import RegistroAgregarVue from '@/modulos/registro/vistas/RegistroAgregarVue.vue';
import RegistroBorrarVue from '@/modulos/registro/vistas/RegistroBorrarVue.vue';

import ComprasVue from '@/modulos/compras/vistas/ComprasVue.vue';
import ComprasAgregarVue from '@/modulos/compras/vistas/ComprasAgregarVue.vue';
import ComprasEditarVue from '@/modulos/compras/vistas/ComprasEditarVue.vue';
import ComprasBorrarVue from '@/modulos/compras/vistas/ComprasBorrarVue.vue';

import { createRouter, createWebHistory } from 'vue-router'
import BienvenidaVue from '@/modulos/principal/vistas/BienvenidaVue.vue';


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    // {
    //   path: '/',
    //   name: 'home',
    //   component: HomeView,
    // },
  {
    path: '/personal',
    name: 'personal',
    component: PersonalVue,
  },
  {
    path: '/personal/agregar',
    name: 'personalagregar',
    component: PersonalAgregarVue,
  },
  {
    path: '/personal/:id/editar',
    name: 'personaleditar',
    component: PersonalEditarVue,
  },
  {
    path: '/personal/:id/borrar',
    name: 'personalborrar',
    component: PersonalBorrarVue,
  },

   //CLIENTES
  {
    path: '/clientes',
    name: 'clientes',
    component: ClientesVue,
  },
  {
    path: '/clientes/agregar',
    name: 'agregar-cliente',
    component: ClientesAgregarVue,
  },
  {
    path: '/clientes/:id/editar',
    name: 'editar-cliente',
    component: ClientesEditarVue,
  },
  {
    path: '/clientes/:id/borrar',
    name: 'borrar-cliente',
    component: ClientesBorrarVue,
  },

   //ARTICULOS
  {
    path: '/articulos',
    name: 'articulos',
    component: ArticulosVue,
  },
  {
    path: '/articulos/agregar',
    name: 'agregar-articulo',
    component: ArticulosAgregarVue,
   },
  {
    path: '/articulos/:id/editar',
    name: 'editar-articulo',
    component: ArticulosEditarVue,
  },
  {
    path: '/articulos/:id/borrar',
    name: 'borrar-articulo',
    component: ArticulosBorrarVue,
  },

   // Rutas de Ventas
  {
    path: '/ventas',
    name: 'ventas',
    component: VentasVue,
  },
  {
    path: '/ventas/agregar',
    name: 'agregar-venta',
    component: VentasAgregarVue,
  },
  {
    path: '/ventas/:id/editar',
    name: 'editar-venta',
    component: VentasEditarVue,
  },
  {
    path: '/ventas/:id/borrar',
    name: 'borrar-venta',
    component: VentasBorrarVue,
  },
  
  //REGISTRO  
  {
    path: '/registro',
    name: 'registro',
    component: RegistroVue,
  },
  {
    path: '/registro/agregar',
    name: 'agregar-registro',
    component: RegistroAgregarVue,
  },
  {
    path: '/registro/:id/borrar',
    name: 'borrar-registro',
    component: RegistroBorrarVue,
  },
  
  // Rutas de Compras
  {
    path: '/compras',
    name: 'compras',
    component: ComprasVue,
  },
  {
    path: '/compras/agregar',
    name: 'agregar-compra',
    component: ComprasAgregarVue,
  },
  {
    path: '/compras/:id/editar',
    name: 'editar-compra',
    component: ComprasEditarVue,
  },
  {
    path: '/compras/:id/borrar',
    name: 'borrar-compra',
    component: ComprasBorrarVue,
  },
  { 
    path: '/bienvenida',
    name: 'bienvenida',
    component: BienvenidaVue,
  }, 
  ],
})

export default router
